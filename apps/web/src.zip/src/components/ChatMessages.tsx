import { useEffect, useRef } from "react";
import MessageBubble from "./MessageBubble";
import type { Message } from "../types/chat";

type Props = {
  messages: Message[];
};

export default function ChatMessages({ messages }: Props) {
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  }, [messages]);

  return (
    <div className="flex-1 overflow-y-auto bg-slate-900 px-8 py-8">
      <div className="mx-auto flex max-w-4xl flex-col">
        {messages.map((message) => (
        <MessageBubble
  key={message.id}
  message={message}
/>
        ))}

        {/* Auto Scroll Target */}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}