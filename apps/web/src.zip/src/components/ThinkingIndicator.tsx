export default function ThinkingIndicator() {
  return (
    <div className="flex items-start gap-3 px-6 py-4">
      {/* AI Avatar */}
      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 text-lg shadow-lg">
        🤖
      </div>

      {/* Bubble */}
      <div className="rounded-2xl rounded-tl-md border border-slate-700 bg-slate-800 px-5 py-4 shadow-md">
        <p className="mb-3 text-sm font-medium text-slate-300">
          AI is thinking...
        </p>

        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 animate-bounce rounded-full bg-indigo-400"></span>
          <span
            className="h-2.5 w-2.5 animate-bounce rounded-full bg-indigo-400"
            style={{ animationDelay: "150ms" }}
          ></span>
          <span
            className="h-2.5 w-2.5 animate-bounce rounded-full bg-indigo-400"
            style={{ animationDelay: "300ms" }}
          ></span>
        </div>
      </div>
    </div>
  );
}