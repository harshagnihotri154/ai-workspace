import { useState } from "react";
import { SendHorizontal } from "lucide-react";

type ChatInputProps = {
  onSend: (message: string) => void;
  disabled: boolean;
};

export default function ChatInput({
  onSend,
  disabled,
}: ChatInputProps) {
  const [message, setMessage] = useState("");

  const handleSend = () => {
    if (!message.trim()) return;

    onSend(message);
    setMessage("");
  };

  return (
    <div className="border-t border-slate-800 bg-slate-900/80 backdrop-blur-xl p-5">
      <div className="mx-auto flex max-w-4xl items-end gap-3 rounded-2xl border border-slate-700 bg-slate-800 p-3 shadow-xl">

        <textarea
          rows={1}
          value={message}
          placeholder="Ask anything..."
          disabled={disabled}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSend();
            }
          }}
          className="max-h-40 flex-1 resize-none bg-transparent px-2 py-2 text-white placeholder:text-slate-500 outline-none"
        />

        <button
          onClick={handleSend}
          disabled={disabled || !message.trim()}
          className="flex h-11 w-11 items-center justify-center rounded-xl bg-indigo-600 text-white transition-all duration-200 hover:scale-105 hover:bg-indigo-500 disabled:cursor-not-allowed disabled:bg-slate-700 disabled:text-slate-500"
        >
          <SendHorizontal size={18} />
        </button>
      </div>

      <p className="mt-3 text-center text-xs text-slate-500">
        AI Workspace may generate incorrect information. Verify important responses.
      </p>
    </div>
  );
}