import { Bot, User } from "lucide-react";
import ThinkingIndicator from "./ThinkingIndicator";
import type { Message } from "../types/chat";

type Props = {
  message: Message;
};

export default function MessageBubble({ message }: Props) {
  const { role, content, isThinking } = message;

  const isUser = role === "user";

  if (!isUser && isThinking) {
    return (
      <div className="mb-8">
        <ThinkingIndicator />
      </div>
    );
  }

  return (
    <div
      className={`mb-8 flex items-end gap-3 ${
        isUser ? "justify-end" : "justify-start"
      }`}
    >
      {/* AI Avatar */}
      {!isUser && (
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 shadow-lg">
          <Bot size={20} className="text-white" />
        </div>
      )}

      <div className="flex max-w-[85%] md:max-w-[75%] flex-col">
        <span
          className={`mb-2 text-xs font-medium ${
            isUser
              ? "text-right text-slate-500"
              : "text-slate-400"
          }`}
        >
          {isUser ? "You" : "AI Workspace"}
        </span>

        <div
          className={`rounded-3xl px-5 py-4 shadow-lg transition-all duration-300 ${
            isUser
              ? "rounded-br-md bg-gradient-to-br from-indigo-600 to-violet-600 text-white"
              : "rounded-bl-md border border-slate-700 bg-slate-800 text-slate-100"
          }`}
        >
          <p className="whitespace-pre-wrap break-words text-[15px] leading-7">
            {content}
          </p>
        </div>
      </div>

      {/* User Avatar */}
      {isUser && (
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-slate-700 shadow-lg">
          <User size={18} className="text-white" />
        </div>
      )}
    </div>
  );
}