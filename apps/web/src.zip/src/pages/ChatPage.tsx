import { useState } from "react";
import ChatInput from "../components/ChatInput";
import ChatMessages from "../components/ChatMessages";
import type { Message } from "../types/chat";
import { streamMessage } from "../services/chat.service";

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async (content: string) => {
    const userMessage: Message = {
      id: crypto.randomUUID(),
      role: "user",
      content,
    };

    const assistantId = crypto.randomUUID();

  const assistantMessage: Message = {
  id: assistantId,
  role: "assistant",
  content: "",
  isThinking: true,
};

    setMessages((prev) => [...prev, userMessage, assistantMessage]);

    setIsLoading(true);


    try {
      await streamMessage(content, (chunk) => {
  setMessages((prev) =>
    prev.map((message) => {
      if (message.id !== assistantId) return message;

      return {
        ...message,
        content: message.content + chunk,
        isThinking: false,
      };
    })
  );
});
    } catch (err) {
      console.error(err);

      setMessages((prev) =>
        prev.map((message) =>
          message.id === assistantId
            ? {
                ...message,
                content: "Something went wrong.",
              }
            : message
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 p-6">
      <div className="mx-auto flex h-full w-full max-w-6xl flex-col overflow-hidden rounded-3xl border border-slate-800 bg-slate-900 shadow-[0_20px_80px_rgba(0,0,0,0.5)]">

        {/* Header */}
        <header className="flex items-center justify-between border-b border-slate-800 bg-gradient-to-r from-slate-900 via-slate-900 to-slate-800 px-8 py-5">
          <div>
            <h1 className="text-3xl font-bold text-white">
              🤖 AI Workspace
            </h1>

            <p className="mt-1 text-sm text-slate-400">
              Build • Learn • Ship AI Applications
            </p>
          </div>

          <div className="flex items-center gap-2 rounded-full bg-green-500/10 px-4 py-2 text-sm font-medium text-green-400">
            <div className="h-2 w-2 rounded-full bg-green-400"></div>
            Online
          </div>
        </header>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto bg-slate-900">
          {messages.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <div className="mb-6 text-6xl">🤖</div>

              <h2 className="text-3xl font-bold text-white">
                Welcome to AI Workspace
              </h2>

              <p className="mt-3 max-w-lg text-slate-400">
                Ask coding questions, debug applications,
                generate ideas, learn new technologies,
                or build your next project.
              </p>

              <div className="mt-10 grid gap-3">
                <div className="rounded-xl border border-slate-700 bg-slate-800 px-6 py-3 text-slate-300">
                  💡 Explain React Fiber
                </div>

                <div className="rounded-xl border border-slate-700 bg-slate-800 px-6 py-3 text-slate-300">
                  🚀 Build a Node.js REST API
                </div>

                <div className="rounded-xl border border-slate-700 bg-slate-800 px-6 py-3 text-slate-300">
                  🧠 Teach me System Design
                </div>
              </div>
            </div>
          ) : (
            <>
              <ChatMessages messages={messages} />

            
            </>
          )}
        </div>

        {/* Input */}
        <ChatInput
          onSend={handleSend}
          disabled={isLoading}
        />
      </div>
    </div>
  );
}